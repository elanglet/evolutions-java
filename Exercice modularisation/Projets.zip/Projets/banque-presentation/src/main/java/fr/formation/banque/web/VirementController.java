package fr.formation.banque.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import fr.formation.banque.metier.BanqueService;
import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

@Controller
@SessionAttributes({"leClient"})
public class VirementController {

	@Autowired
	@Qualifier("banqueService")
	private BanqueService banqueService;

	@RequestMapping(value="/virement.do", method=RequestMethod.GET)
	public String showForm(@ModelAttribute("leClient") Client client, ModelMap model) {
		try {
			List<Compte> listeComptes = banqueService.mesComptes(client);
		
			model.addAttribute("lesComptes", listeComptes);
			
			return "virement";
		} 
		catch (BanqueException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@ModelAttribute("virementForm")
	public VirementForm initForm() {
		return new VirementForm();
	}
	
	@RequestMapping(
			method=RequestMethod.POST
	)
	public String submitForm(
		@ModelAttribute("virementForm") VirementForm virementForm, 
		@ModelAttribute("leClient") Client client, 
		ModelMap model
	) {
		try {
			banqueService.virement(
				Long.parseLong(virementForm.getDebiter()), 
				Long.parseLong(virementForm.getCrediter()), 
				Double.parseDouble(virementForm.getMontant())
			);
			
			List<Compte> listeDeComptes = banqueService.mesComptes(client);
			model.addAttribute("lesComptes", listeDeComptes);
			return "comptes";
		} 
		catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
