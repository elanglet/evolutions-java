package fr.formation.banque.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

public class HibernateCompteDAO extends HibernateDaoSupport implements CompteDAO {

	public void ajouterCompte(Compte compte) throws BanqueException {
		try {
			getHibernateTemplate().merge(compte);
		} 
		catch (DataAccessException e) {
			throw new BanqueException("Erreur d'ajout du compte.");
		}
	}

	public Compte rechercherCompteParNumero(long numero) throws BanqueException {
		return getHibernateTemplate().load(Compte.class, numero);
	}

	public List<Compte> rechercherComptesClient(Client client) throws BanqueException {
		try {
			return (List<Compte>) getHibernateTemplate().findByNamedQuery(
				"rechercher.comptes.client",
				client.getId()
			);
		} 
		catch (DataAccessException e) {
			throw new BanqueException("Erreur de r�cup�ration des comptes.");
		}
	}

	public void virementEntreComptes(Compte aDebiter, Compte aCrediter, double montant) throws BanqueException {
		try {
			aDebiter.setSolde(aDebiter.getSolde() - montant);
			getHibernateTemplate().update(aDebiter);
			aCrediter.setSolde(aCrediter.getSolde() + montant);
			getHibernateTemplate().update(aCrediter);
		}
		catch (DataAccessException e) {
			throw new BanqueException("Erreur lors de la r�alisation du virement.");
		}
	}

}
