package fr.formation.banque.jms;

import java.io.Serializable;

public class VirementMessage implements Serializable {

	private String debit;
	private String credit;
	private String montant;

	public String getDebit() {
		return debit;
	}

	public void setDebit(String debit) {
		this.debit = debit;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getMontant() {
		return montant;
	}

	public void setMontant(String montant) {
		this.montant = montant;
	}

}
