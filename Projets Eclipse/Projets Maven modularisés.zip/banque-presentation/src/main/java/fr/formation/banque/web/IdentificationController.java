package fr.formation.banque.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import fr.formation.banque.metier.BanqueService;
import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;

@Controller
@SessionAttributes({"leClient"})
public class IdentificationController {

	// Injection du banqueSErvice (Par annotation)
	@Autowired
	@Qualifier("banqueService")
	private BanqueService banqueService;
	
	public void setBanqueService(BanqueService banqueService) {
		this.banqueService = banqueService;
	}

	// 1. M�thode d'affichage du formulaire.
	//   - Elle doit �tre invoqu�e en GET
	//   - Renvoi l'identifiant de la JSP de formulaire
	@RequestMapping(value="/identification.do", method=RequestMethod.GET)
	public String showForm() {
		return "identification";
	}
	
	// 2. M�thode d'initialisation du bean 
	//  - Elle retourne une instance du bean
	//  - Elle doit �tre annot�e avec @ModelAttribute
	@ModelAttribute("identificationForm")
	public IdentificationForm initForm() {
		IdentificationForm form = new IdentificationForm();
		// On pourrait initialiser le bean avec des valeurs ...
		// ...
		return form;
	}
	
	// 3. M�thode de traitement ud formulaire
	//   - En POST
	//   - Re�oit un param�tre du type du bean annot� avec @ModelAttribute
	@RequestMapping(method=RequestMethod.POST)
	public String submitForm(
		@ModelAttribute("identificationForm") IdentificationForm form,
		ModelMap model
	) {
		try {
			Client client = banqueService.authentifier(
				form.getIdentifiant(),
				form.getMotDePasse()
			);
			List<Compte> listeComptes = banqueService.mesComptes(client);
			model.addAttribute("leClient", client);
			model.addAttribute("lesComptes", listeComptes);
			return "comptes";
		} 
		catch(Exception e) {
			e.printStackTrace();
			String message = e.getMessage();
			model.addAttribute("message", message);
			return "identification";
		}
	}
}





