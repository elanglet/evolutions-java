module fr.formation.banque.presentation {
	exports fr.formation.banque.web;

	requires fr.formation.banque.metier;
	requires fr.formation.banque.persistance;
	requires java.logging;
	requires java.prefs;
	requires spring.beans;
	requires spring.context;
	requires spring.web;
}