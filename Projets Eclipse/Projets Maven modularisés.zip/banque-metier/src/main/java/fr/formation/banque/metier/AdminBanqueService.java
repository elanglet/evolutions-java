package fr.formation.banque.metier;

import java.util.List;

import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

public interface AdminBanqueService {

	public abstract void ajouterClient(Client client) 
		throws BanqueException;
	
	public abstract void ajouterCompte(Compte compte) 
		throws BanqueException;
		
	public abstract List<Client> rechercherTousLesClients() 
		throws BanqueException;
}
