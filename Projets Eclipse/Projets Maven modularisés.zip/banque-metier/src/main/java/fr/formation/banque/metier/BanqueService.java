package fr.formation.banque.metier;

import java.util.List;

import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

public interface BanqueService {

	public abstract Client authentifier(String login, String password)
		throws BanqueException;
	
	public abstract List<Compte> mesComptes(Client client) 
		throws BanqueException;
	
	public abstract void virement(
		long numeroDebit, long numeroCredit, double montant
	) throws BanqueException;

}












