package fr.formation.banque.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import fr.formation.banque.metier.BanqueService;
import fr.formation.banque.util.BanqueException;

public class VirementMessageRecepteur implements MessageListener {

	// On injecte le BanqueService
	private BanqueService banqueService;
	
	public void setBanqueService(BanqueService banqueService) {
		this.banqueService = banqueService;
	}

	// M�thode invoqu�e par le conteneur l�ger Spring lorsqu'un
	// message est disponible pour ce r�cepteur
	public void onMessage(Message message) {
		if(message != null && message instanceof ObjectMessage) {
			try {
				// On a bien un message de type ObjectMessage
				// On r�cup�re l'objet � l'int�rieur du message
				ObjectMessage oMessage = (ObjectMessage) message;
				Object o = oMessage.getObject();
				// On v�rifie que l'on a bien un 'VirementForm'
				if(o != null && o instanceof VirementMessage) {
					VirementMessage virementMessage = (VirementMessage) o;
					// On peut r�aliser le virement ...
					long debit = Long.parseLong(virementMessage.getDebit());
					long credit = Long.parseLong(virementMessage.getCredit());
					double montant = Double.parseDouble(virementMessage.getMontant());
					
					banqueService.virement(debit, credit, montant);
				}
			}  
			catch (JMSException e) {
				e.printStackTrace();
			} 
			catch (BanqueException e) {
				e.printStackTrace();
			}
		}
	}
}
