package fr.formation.banque.metier;

import java.util.List;

import fr.formation.banque.dao.ClientDAO;
import fr.formation.banque.dao.CompteDAO;
import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

public class AdminBanqueServiceImpl implements AdminBanqueService {

	// Injection des DAO
	private ClientDAO clientDAO;
	private CompteDAO compteDAO;
	
	public void setClientDAO(ClientDAO clientDAO) {
		this.clientDAO = clientDAO;
	}

	public void setCompteDAO(CompteDAO compteDAO) {
		this.compteDAO = compteDAO;
	}

	public void ajouterClient(Client client) throws BanqueException {
		try {
			clientDAO.ajouterClient(client);
		} 
		catch (Exception e) {
			throw new BanqueException("Erreur d'ajout du client.");
		}
	}

	public void ajouterCompte(Compte compte) throws BanqueException {
		try {
			compteDAO.ajouterCompte(compte);
		} 
		catch (Exception e) {
			throw new BanqueException("Erreur d'ajout du compte.");
		}
	}

	public List<Client> rechercherTousLesClients() throws BanqueException {
		try {
			return clientDAO.rechercherTousLesClients();
		} 
		catch (Exception e) {
			throw new BanqueException("Erreur de r�cup�ration de la liste des clients.");
		}
	}

}
