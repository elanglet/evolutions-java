package fr.formation.banque.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class VirementMessageProducteur {

	// On injecte le JmsTemplate pour b�n�ficier de 
	// m�thodes de haut niveau ...
	private JmsTemplate jmsTemplate;

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}
	
	// M�thode de production et d'envoi du message JMS
	// Elle prend en param�tre le bean de formulaire VirementForm
	// qui contient les donn�es pour le virement
	public void envoyerMessageVirement(final VirementMessage virementMessage) {
		// On utilise la m�thode send() du jmsTemplate ...
		jmsTemplate.send(new MessageCreator() {		
			public Message createMessage(Session session) throws JMSException {
				// On cr�� � partir de la session, un ObjectMessage
				// dans lequel on met le VirementForm
				ObjectMessage message = session.createObjectMessage(virementMessage);
				return message;
			}
		});
	}
	
}












