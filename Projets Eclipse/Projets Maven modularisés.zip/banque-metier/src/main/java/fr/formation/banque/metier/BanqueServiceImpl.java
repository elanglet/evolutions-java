package fr.formation.banque.metier;

import java.util.List;

import fr.formation.banque.dao.ClientDAO;
import fr.formation.banque.dao.CompteDAO;
import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

public class BanqueServiceImpl implements BanqueService {

	// La classe n�cessite les DAO pour r�aliser ses op�rations
	// On injecte les DAO (typ�s avec leurs interface)
	private CompteDAO compteDAO;
	private ClientDAO clientDAO;
		
	public void setCompteDAO(CompteDAO compteDAO) {
		this.compteDAO = compteDAO;
	}

	public void setClientDAO(ClientDAO clientDAO) {
		this.clientDAO = clientDAO;
	}

	public Client authentifier(String login, String password) throws BanqueException {
		try {
			long id = Long.parseLong(login);
			Client client = clientDAO.rechercherClientParId(id);
			if(
				client != null && 
				password != null &&
				password.equals(client.getMotDePasse())
			) {
				return client;
			}
			else {
				throw new Exception();
			}
		} 
		catch (Exception e) {
			throw new BanqueException("Erreur d'authentification.");
		}
	}

	public List<Compte> mesComptes(Client client) throws BanqueException {
		return compteDAO.rechercherComptesClient(client);
	}

	public void virement(long numeroDebit, long numeroCredit, double montant) throws BanqueException {
		try {
			Compte aDebiter = compteDAO.rechercherCompteParNumero(numeroDebit);
			Compte aCrediter = compteDAO.rechercherCompteParNumero(numeroCredit);
			compteDAO.virementEntreComptes(aDebiter, aCrediter, montant);
		} 
		catch (Exception e) {
			throw new BanqueException("Erreur lors de la r�alisation du virement.");	
		}
	}

}














