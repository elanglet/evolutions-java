module fr.formation.banque.metier {
	exports fr.formation.banque.metier;
	exports fr.formation.banque.jms;

	requires fr.formation.banque.persistance;
	requires java.logging;
	requires java.prefs;
	requires javax.jms.api;
	requires spring.beans;
	requires spring.core;
	requires spring.jms;
}