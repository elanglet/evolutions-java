module fr.formation.banque.persistance {

	exports fr.formation.banque.util;
	exports fr.formation.banque.dao;
	exports fr.formation.banque.to;

	requires hibernate.core;
	requires java.instrument;
	requires java.logging;
	requires java.management;
	requires java.prefs;
	requires junit;
	requires spring.beans;
	requires spring.context;
	requires spring.core;
	requires spring.orm;
	requires spring.tx;
}