package fr.formation.banque.dao;

import java.util.List;

import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;
import fr.formation.banque.util.BanqueException;

public interface CompteDAO {

	public abstract void ajouterCompte(Compte compte) 
		throws BanqueException;
	
	public abstract Compte rechercherCompteParNumero(long numero)
		throws BanqueException;
	
	public abstract List<Compte> rechercherComptesClient(Client client)
		throws BanqueException;
	
	public abstract void virementEntreComptes(
		Compte aDebiter, Compte aCrediter, double montant	
	) throws BanqueException;
	
}









