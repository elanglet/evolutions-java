package fr.formation.banque.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import fr.formation.banque.to.Client;
import fr.formation.banque.util.BanqueException;

public class HibernateClientDAO extends HibernateDaoSupport implements ClientDAO {

	public void ajouterClient(Client client) throws BanqueException {
		try {
			getHibernateTemplate().persist(client);
		} 
		catch (DataAccessException e) {
			throw new BanqueException("Erreur d'ajout du client.");
		}
	}

	public Client rechercherClientParId(long id) throws BanqueException {
		try {
			return getHibernateTemplate().load(Client.class, id);
		} 
		catch (DataAccessException e) {
			throw new BanqueException("Erreur de chargement du client.");
		}
	}

	public List<Client> rechercherTousLesClients() throws BanqueException {
		try {
			return getHibernateTemplate().loadAll(Client.class);
		} 
		catch (DataAccessException e) {
			throw new BanqueException("Erreur de chargement des clients.");
		}
	}

}
