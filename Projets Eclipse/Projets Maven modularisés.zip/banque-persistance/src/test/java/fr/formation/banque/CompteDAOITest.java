package fr.formation.banque;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.formation.banque.dao.ClientDAO;
import fr.formation.banque.dao.CompteDAO;
import fr.formation.banque.to.Client;
import fr.formation.banque.to.Compte;

@FixMethodOrder(value=MethodSorters.NAME_ASCENDING)
public class CompteDAOITest {

	private static CompteDAO compteDAO;
	private static Client client;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext-persistance.xml");
		compteDAO = (CompteDAO) context.getBean("compteDAO");
		ClientDAO clientDAO = (ClientDAO) context.getBean("clientDAO");
		
		assertNotNull(compteDAO);
		assertNotNull(clientDAO);
		
		client = clientDAO.rechercherClientParId(1);
		assertNotNull(client);
	}

	@Test
	public void testAjouterCompte() {
		try {
			Compte compte = new Compte();
			compte.setNumero(341543512);
			compte.setClient(client);
			compte.setSolde(1000.00);
			compteDAO.ajouterCompte(compte);
		} 
		catch (Exception e) {
			fail(e.getCause() + " " + e.getMessage());
		}
	}

	@Test
	public void testRechercherCompteParNumero() {
		try {
			Compte compte = compteDAO.rechercherCompteParNumero(245646786);
			assertEquals(new Double(8400.00), new Double(compte.getSolde()));
			assertEquals(client.getId(), compte.getClient().getId());
		} 
		catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void testRechercherComptesClient() {
		try {
			List<Compte> liste = compteDAO.rechercherComptesClient(client);
			assertNotNull(liste);
			assertEquals(3, liste.size());
		} 
		catch (Exception e) {
			fail(e.getMessage());
		}
		
	}

	@Test
	public void testVirementEntreComptes() {
		try {
			Compte compte1 = compteDAO.rechercherCompteParNumero(245646786);
			Compte compte2 = compteDAO.rechercherCompteParNumero(263434345);
			compteDAO.virementEntreComptes(compte1, compte2, 100.00);
			compte1 = compteDAO.rechercherCompteParNumero(245646786);
			assertEquals(new Double(8300.00), new Double(compte1.getSolde()));
			compte2 = compteDAO.rechercherCompteParNumero(263434345);
			assertEquals(new Double(20100.00), new Double(compte2.getSolde()));
		} 
		catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
}
