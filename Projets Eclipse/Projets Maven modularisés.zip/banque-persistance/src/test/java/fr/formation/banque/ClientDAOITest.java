package fr.formation.banque;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import fr.formation.banque.dao.ClientDAO;
import fr.formation.banque.to.Client;

public class ClientDAOITest {

	private static ClientDAO clientDAO;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext-persistance.xml");
		clientDAO = (ClientDAO) context.getBean("clientDAO");
	}

	@Test
	public void testAjouterClient() {
		try {
			Client client = new Client();
			client.setNom("LANGLET");
			client.setPrenom("Etienne");
			client.setAdresse("4 Les Laures");
			client.setCodePostal("44330");
			client.setVille("Vallet");
			client.setMotDePasse("secret");
			clientDAO.ajouterClient(client);
		}
		catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void testRechercherClientParId() {
		try {
			Client client = clientDAO.rechercherClientParId(1);
			assertNotNull(client);
			assertEquals(client.getId(), 1);
			assertEquals(client.getNom(), "DUPONT");
			assertEquals(client.getPrenom(), "Robert");
			assertEquals(client.getAdresse(), "40 rue de la Paix");
			assertEquals(client.getCodePostal(), "75000");
			assertEquals(client.getVille(), "Paris");
			assertEquals(client.getMotDePasse(), "password");
		} 
		catch (Exception e) {
			fail(e.getMessage());
		}
	
	}

	@Test
	public void testRechercherTousLesClients() {
		try {
			List<Client> liste = clientDAO.rechercherTousLesClients();
			assertNotNull(liste);
			assertSame(liste.size(), 4);
		} 
		catch (Exception e) {
			fail(e.getMessage());
		}
	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		
	}
}
