module fr.formation.httpclient {
	requires java.net.http;
	
}