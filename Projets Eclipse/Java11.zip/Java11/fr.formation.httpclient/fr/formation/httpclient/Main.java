package fr.formation.httpclient;

import java.io.IOException;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {

	public static void main(String[] args) {
		
//		// Connexion via un proxy avec authentification
//		var httpClient = HttpClient.newBuilder()
//				.proxy(ProxySelector.of(
//					new InetSocketAddress("172.16.23.30", 8080))
//				)
//				.authenticator(new Authenticator() {
//					protected PasswordAuthentication getPasswordAuthentication() {
//						return new PasswordAuthentication("admin", "password".toCharArray());
//					};
//				}
//				).build();
		
		try {
			var httpClient = HttpClient.newHttpClient();
			
			var httpRequest = HttpRequest.newBuilder()
					.uri(new URI("http://www.google.fr"))
					.GET()
					//.POST(BodyPublishers.ofFile(Paths.get("./fichier.txt")))
					.build();
			
			var httpResponse = httpClient.send(httpRequest, BodyHandlers.ofString());
			
			System.out.println("Status Code : " + httpResponse.statusCode());
			System.out.println("R�ponse : " + httpResponse.body());
			
		} 
		catch (URISyntaxException | IOException | InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}




