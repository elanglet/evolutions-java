package fr.formation.date;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Experimentations2 {

	public static void main(String[] args) {

		List<Personne> personnes = new ArrayList<>();
		personnes.add(new Personne("DUPONT", "Robert", LocalDate.of(1956, Month.APRIL, 23)));
		personnes.add(new Personne("MARTIN", "St�phane", LocalDate.of(1962, Month.MAY, 15)));
		personnes.add(new Personne("DURANT", "Kevin", LocalDate.of(2001, Month.MARCH, 29)));
		personnes.add(new Personne("DUBOIS", "Bruno", LocalDate.of(2004, Month.JUNE, 8)));
		personnes.add(new Personne("PERDIC", "Jos�", LocalDate.of(1944, Month.NOVEMBER, 15)));
		personnes.add(new Personne("RIALLEC", "La�la", LocalDate.of(2008, Month.MARCH, 23)));
				
		LocalDate today = LocalDate.now();
		
		// 1. Cr�er une nouvelle liste ne contenant que les personnes mineures
//		List<Personne> mineurs = new ArrayList<>();
//		for(Personne p : personnes) {
//			if(Period.between(p.getDateDeNaissance(), today).getYears() < 18) {
//				mineurs.add(p);
//			}
//		}
		
// OU:		
		List<Personne> mineurs = personnes.stream().filter(
			p -> Period.between(p.getDateDeNaissance(), today).getYears() < 18
		).collect(Collectors.toList());

		
		System.out.println(" *** Les personnes mineures *** ");
//		for(Personne p : mineurs) {
//			System.out.println(p.getPrenom() + " " + p.getNom());
//		}
		
// OU:		
		mineurs.forEach((p) -> System.out.println(p.getPrenom() + " " + p.getNom()));
		
		
		// 2. Trier la liste de la personne la plus jeune � la plus ancienne
//		Collections.sort(personnes, 
//		(p1, p2) -> 
//			p1.getDateDeNaissance().isAfter(p2.getDateDeNaissance()) ? -1 : 1
//	);
		personnes.sort(
			(p1, p2) -> 
				p1.getDateDeNaissance().isAfter(p2.getDateDeNaissance()) ? -1 : 1
		);
	
		System.out.println(" *** Les personnes de la plus jeune � la plus ancienne *** ");
//		for(Personne p : personnes) {
//			System.out.println(p.getPrenom() + " " + p.getNom());
//		}
		personnes.forEach((p) -> System.out.println(p.getPrenom() + " " + p.getNom()));

	
	}

}
