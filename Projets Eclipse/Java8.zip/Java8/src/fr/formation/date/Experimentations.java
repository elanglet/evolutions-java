package fr.formation.date;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.ChronoUnit;

public class Experimentations {

	public static void main(String[] args) {
		
		LocalDateTime toutDeSuite = LocalDateTime.now();
		System.out.println(toutDeSuite);
		
		DateTimeFormatter format1 = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
		System.out.println(toutDeSuite.format(format1));
		
		LocalDate naissance = LocalDate.of(1978, Month.MARCH, 22);
		
		// Period entre 2 dates
		Period age = Period.between(naissance, toutDeSuite.toLocalDate());
		System.out.println(
			age.getYears() + " ans, " +	
			age.getMonths() + " mois, " +	
			age.getDays() + " jours"	
		);
		
		long ageEnJours = ChronoUnit.DAYS.between(naissance, toutDeSuite.toLocalDate());
		
		System.out.println("Age en jours : " + ageEnJours);
		
		// Dans 100 jours ...
		LocalDate dans100Jours = toutDeSuite.plusDays(100).toLocalDate();
		System.out.println("Dans 100 jours : " + dans100Jours.format(format1));
		
		DateTimeFormatter datetimeSQL = DateTimeFormatter.ofPattern("uuuu-MM-dd kk:mm:ss");
		System.out.println("DateTime : " + toutDeSuite.format(datetimeSQL));
	}
	
}
