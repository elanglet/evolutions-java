package fr.formation.streams;

public class Voiture extends Vehicule implements Vidangeable {
	
	public Voiture(String marque, String modele, int kilometrage) {
		super(marque, modele, kilometrage);
	}

	@Override
	public void faireLaVidange() {
		System.out.println("Vidange de la voiture ...");
	}

}
