package fr.formation.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Experimentations {

	public static void main(String[] args) {

		List<Vehicule> vehicules = new ArrayList<>();
		
		vehicules.add(new Voiture("Peugeot", "307", 126000));
		vehicules.add(new Velo("Decathlon", "Rockrider", 556));
		vehicules.add(new Voiture("Peugeot", "308", 25233));
		vehicules.add(new Moto("Suzuki", "Bandit 600", 25000));
		vehicules.add(new Velo("Peugeot", "Super Course", 2563));
		vehicules.add(new Moto("Kawasaki", "ZZR 1400", 66000));
		vehicules.add(new Voiture("Citroen", "C4", 33000));
		
		// 1. Calculer la somme des kilom�trages
		System.out.println(" *** 1. Calculer la somme des kilom�trages *** ");
		Optional<Integer> somme = vehicules.stream()
				.map(v -> v.getKilometrage())
					.reduce((i,k) -> i + k);
		
		if(somme.isPresent())
			System.out.println("Somme des kilom�trages : " + somme.get());
		
		
		// OU Directement 
		// int somme = vehicules.stream()
		//		.map(v -> v.getKilometrage()).reduce(0, (i,k) -> i + k);
		//
		
		// 2. Faire la vidange des v�hicules ayant plus de 50000 kms
		System.out.println(" *** 2. Faire la vidange des v�hicules ayant plus de 50000 kms *** ");
		vehicules.stream()
			.filter(v -> v instanceof Vidangeable)
			.filter(v -> v.getKilometrage() >= 50000)
			.map(v -> (Vidangeable) v)
			.forEach(v -> v.faireLaVidange());
		
		// 3. Afficher DIRECTEMENT la liste unique des marques de v�hicules
		System.out.println(" *** 3. Afficher DIRECTEMENT la liste unique des marques de v�hicules *** ");
		vehicules.stream()
			.map(v -> v.getMarque())	
			.distinct()
			//.forEach(System.out::println);
			.forEach(m -> System.out.println(m));
		
		// 4. Cr�er une collection contenant uniquement les v�hicules de marque "Peugeot"
		System.out.println(" *** 4. Cr�er une collection contenant uniquement les v�hicules de marque \"Peugeot\" *** ");
		List<Vehicule> listeVehiculesPeugeot = vehicules.stream()
				.filter(v -> "Peugeot".equals(v.getMarque()))
				.collect(Collectors.toList());
		listeVehiculesPeugeot.forEach(v -> System.out.println(v.getModele()));
		
		// 5. Afficher DIRECTEMENT le nombre de moto d�passant les 30000 kms
		System.out.println(" *** 5. Afficher DIRECTEMENT le nombre de moto d�passant les 30000 kms *** ");
		System.out.println(vehicules.stream()
				.filter(v -> v instanceof Moto)
				.filter(v -> v.getKilometrage() > 30000)
				.count()
		);
		
	}

}
