package fr.formation.streams;

public class Velo extends Vehicule {

	public Velo(String marque, String modele, int kilometrage) {
		super(marque, modele, kilometrage);
	}

}
