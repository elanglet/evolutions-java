package fr.formation.streams;

public class Moto extends Vehicule implements Vidangeable {
	
	public Moto(String marque, String modele, int kilometrage) {
		super(marque, modele, kilometrage);
	}

	@Override
	public void faireLaVidange() {
		System.out.println("Vidange de la moto ...");
	}

}
