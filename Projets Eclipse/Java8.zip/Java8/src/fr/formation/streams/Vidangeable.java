package fr.formation.streams;

public interface Vidangeable {

	void faireLaVidange();
	
}
