package fr.formation.lambda;

@FunctionalInterface
public interface Instrument {
	
	public abstract void jouer();
	
	public default void a() {
		System.out.println("M�thode a()");
	}
	
	public static void b() {
		System.out.println("M�thode statique b()");
	}
	
}
