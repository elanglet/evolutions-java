package fr.formation.lambda;

public class Experimentations {

	public static void main(String[] args) {

		// 1. En utilisant une classe impl�mentant l'interface
		System.out.println(" *** 1. En utilisant une classe impl�mentant l'interface *** ");
		Instrument saxo1 = new Saxophone();
		saxo1.jouer();
		saxo1.a();
		
		// INTERDIT : 
		// saxo1.b();
		// Saxophone.b();
		Instrument.b();
		
		// 2. En utilisant une classe anonyme
		System.out.println(" *** 2. En utilisant une classe anonyme *** ");
		Instrument saxo2 = new Instrument() {
			@Override
			public void jouer() {
				System.out.println("Sax, sax, sax ...");
			}
		};
		
		saxo2.jouer();
		saxo2.a();
		
		// 3. En utilisant les lambdas
		// Instrument saxo3 = () -> System.out.println("Sax, sax, sax ...");
		Instrument saxo3 = () -> {
			System.out.println("Sax, sax, sax ...");
		};
		saxo3.jouer();
		saxo3.a();
		
		
		
		
	}

}






