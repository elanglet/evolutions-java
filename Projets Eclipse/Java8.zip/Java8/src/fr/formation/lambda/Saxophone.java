package fr.formation.lambda;

public class Saxophone implements Instrument {

	@Override
	public void jouer() {
		System.out.println("Sax, sax, sax ...");
	}

}
