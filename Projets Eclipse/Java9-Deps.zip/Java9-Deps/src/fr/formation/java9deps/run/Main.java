package fr.formation.java9deps.run;

import fr.formation.java9.data.Personne;

public class Main {

	public static void main(String[] args) {
		
		Personne p = new Personne("LANGLET", "Etienne");
		
	}

}
