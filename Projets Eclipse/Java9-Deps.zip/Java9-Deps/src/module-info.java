module fr.formation.java9deps {

	requires fr.formation.java9;

}