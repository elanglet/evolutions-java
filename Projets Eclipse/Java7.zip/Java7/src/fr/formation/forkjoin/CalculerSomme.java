package fr.formation.forkjoin;

import java.util.concurrent.RecursiveTask;

public class CalculerSomme extends RecursiveTask<Long> {

	private long[] tableau;
	private int debut;
	private int fin;
	private static final int SEUIL = 5;
	
	public CalculerSomme(long[] tableau, int debut, int fin) {
		super();
		this.tableau = tableau;
		this.debut = debut;
		this.fin = fin;
	}

	@Override
	protected Long compute() {
		// Faut-il diviser la t�che en sous-t�ches ??
		if(fin - debut < SEUIL) {
			// On traite en une seule fois
			long somme = 0;
			for(int i = debut; i < fin; i++) {
				somme += tableau[i];
			}
			return somme;
		}
		else {
			// On divise en 2 sous t�ches
			int milieu = (debut + fin) / 2;
			
			// Sous tache 1
			CalculerSomme st1 = new CalculerSomme(tableau, debut, milieu);
			CalculerSomme st2 = new CalculerSomme(tableau, milieu, fin);
			
			// On lance les sous t�ches
			st1.fork();
			st2.fork();
			
			return st1.join() + st2.join();
			
		}
	}

}






