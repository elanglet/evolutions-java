package fr.formation.forkjoin;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;

public class Lancement {

	public static void main(String[] args) {

		try {
			long[] tableau = {
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8,
				5, 2, 9, 7, 6, 3, 2, 5, 8
			};
			
			// Cr�ation du pool de threads
			ForkJoinPool pool = new ForkJoinPool();
			
			// Cr�er la tache
			CalculerSomme tache = new CalculerSomme(tableau, 0, tableau.length);
			
			// Lancer la t�che
			pool.invoke(tache);
			
			
			// On attend la fin de la tache ....
			while(!tache.isDone())
				Thread.sleep(10);
		
			// Tache termin�e, on peut obtenir le r�sultat
			Long resultat = tache.get();
			
			System.out.println(resultat);
		
		} 
		catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}





