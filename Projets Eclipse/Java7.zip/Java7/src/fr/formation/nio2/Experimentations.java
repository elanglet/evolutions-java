package fr.formation.nio2;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class Experimentations {

	public static void main(String[] args) {

		try {
			Path fichier = Paths.get("monFichier.txt");

			if (Files.exists(fichier)) {
				System.out.println("Le fichier existe");

				List<String> lignes = new ArrayList<>();
				lignes.add("Ligne 1");
				lignes.add("Ligne 2");
				lignes.add("Ligne 3");

				Files.write(fichier, lignes, Charset.defaultCharset());

			} else {
				System.out.println("Le fichier n'existe pas");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Path racine = Paths.get(".");
		
		System.out.println(" *** Pi�ge : Liste des fichiers d'extensions .txt *** ");
		try (DirectoryStream<Path> stream = Files.newDirectoryStream(racine, "*.txt")) {
			for (Path fichier : stream) {
				System.out.println(fichier);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println(" *** Liste des fichiers d'extensions .txt *** ");
		try {
			Files.walkFileTree(racine, new SimpleFileVisitor<Path>() {
				@Override
				public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
					PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:**/*.txt");
					if(matcher.matches(file)) 
						System.out.println(file);
					return FileVisitResult.CONTINUE;
				}
			});
		} 
		catch (IOException e) {
			e.printStackTrace();
		}

	}

}
