package fr.formation.java9.data;

import static org.junit.Assert.*;

import org.junit.Test;

public class PersonneTest {

	@Test
	public void testPersonne() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetNom() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetNom() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPrenom() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetPrenom() {
		fail("Not yet implemented");
	}

}
