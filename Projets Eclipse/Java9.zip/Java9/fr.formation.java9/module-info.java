module fr.formation.java9 {
	
	requires junit;

	// Export du package fr.formation.java9.data
	exports fr.formation.java9.data;
}